exports.AuthRoles = {
  ADMIN: 'ADMIN',
  USER: 'USER',
};
